package app.filestudio;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/** File Studio: the whole tool is one HTML page in assets, shown in a WebView. */
public class MainActivity extends Activity {
    private static final int PICK_FILES = 1;
    private static final int ASK_STORAGE = 2;

    private WebView web;
    private ValueCallback<Uri[]> pendingPick;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingPick != null) pendingPick.onReceiveValue(null);
                pendingPick = callback;
                String[] types = params.getAcceptTypes();
                boolean onlyImages = types != null && types.length == 1 && types[0] != null && types[0].startsWith("image/");
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(onlyImages ? "image/*" : "*/*");
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(pick, "File chuno"), PICK_FILES);
                } catch (Exception e) {
                    pendingPick = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Saver(), "AndroidSave");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FILES || pendingPick == null) return;
        Uri[] picked = null;
        if (result == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null && clip.getItemCount() > 0) {
                picked = new Uri[clip.getItemCount()];
                for (int i = 0; i < picked.length; i++) picked[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                picked = new Uri[]{data.getData()};
            }
        }
        pendingPick.onReceiveValue(picked);
        pendingPick = null;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    /** Puts a finished file into Downloads/FileStudio and returns the name it was saved under. */
    private String publish(File tmp, String name, String mime) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FileStudio");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("File save nahi ho payi");
            InputStream in = new FileInputStream(tmp);
            OutputStream out = getContentResolver().openOutputStream(uri);
            try {
                if (out == null) throw new IOException("File save nahi ho payi");
                copy(in, out);
            } finally {
                in.close();
                if (out != null) out.close();
            }
            v.clear();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, v, null, null);
            return name;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, ASK_STORAGE);
                }
            });
            throw new IOException("Storage ki permission do, phir Download dobara dabao");
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "FileStudio");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Downloads folder nahi bana");
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        File target = new File(dir, name);
        for (int i = 1; target.exists(); i++) target = new File(dir, stem + " (" + i + ")" + ext);
        InputStream in = new FileInputStream(tmp);
        OutputStream out = new FileOutputStream(target);
        try {
            copy(in, out);
        } finally {
            in.close();
            out.close();
        }
        MediaScannerConnection.scanFile(this, new String[]{target.getPath()}, null, null);
        return target.getName();
    }

    private static class Job {
        File tmp;
        OutputStream out;
        String name;
        String mime;
    }

    /** The page hands finished files over in base64 chunks (a WebView cannot download blob: links itself). */
    private class Saver {
        private final Map<Integer, Job> jobs = new HashMap<Integer, Job>();
        private int next = 1;

        @JavascriptInterface
        public synchronized int begin(String name, String mime) {
            try {
                Job j = new Job();
                j.name = (name == null || name.trim().isEmpty()) ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
                j.mime = mime;
                if (j.mime == null || j.mime.isEmpty()) {
                    int dot = j.name.lastIndexOf('.');
                    String guess = dot > 0 ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(j.name.substring(dot + 1).toLowerCase()) : null;
                    j.mime = guess != null ? guess : "application/octet-stream";
                }
                j.tmp = File.createTempFile("save", ".part", getCacheDir());
                j.out = new FileOutputStream(j.tmp);
                jobs.put(next, j);
                return next++;
            } catch (IOException e) {
                toast("File save nahi ho payi: " + e.getMessage());
                return 0;
            }
        }

        @JavascriptInterface
        public synchronized void chunk(int id, String base64) {
            Job j = jobs.get(id);
            if (j == null) return;
            try {
                j.out.write(Base64.decode(base64, Base64.DEFAULT));
            } catch (IOException e) {
                toast("File save nahi ho payi: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public synchronized void end(int id) {
            Job j = jobs.remove(id);
            if (j == null) return;
            try {
                j.out.close();
                String saved = publish(j.tmp, j.name, j.mime);
                toast("Save ho gayi: Downloads/FileStudio/" + saved);
            } catch (IOException e) {
                toast(e.getMessage());
            } finally {
                j.tmp.delete();
            }
        }

        @JavascriptInterface
        public void fail(String msg) {
            toast("File save nahi ho payi: " + msg);
        }
    }
}
